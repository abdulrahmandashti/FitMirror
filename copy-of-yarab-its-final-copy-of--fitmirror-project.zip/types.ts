
export type Language = 'en' | 'ar';
export type Role = 'guest' | 'admin' | 'partner' | 'customer';
export type Gender = 'male' | 'female' | 'unisex';
export type FitPreference = 'tight' | 'regular' | 'relaxed';
export type SizeLabel = 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL';

export interface User {
  id: string;
  username: string;
  password?: string; // For mock auth
  role: Role;
  status: 'active' | 'disabled';
  name?: string;
  email?: string;
  companyId?: string; // For partner users
  preferences?: {
    gender: Gender;
    fit: FitPreference;
    isPregnant: boolean;
    height?: number;
    weight?: number;
  };
  coupons?: Coupon[];
}

export interface Company {
  id: string;
  name: string;
  logo: string;
  status: 'active' | 'inactive';
  isSponsored: boolean;
  commissionRate: number; // e.g., 0.650 KD per match
  totalMatches: number;
  productViews: number;
  communityEngagement: number; // Likes/Comments on brand related posts
  score?: number; // Leaderboard score
  rank?: number;
  couponsIssued: number;
  couponsRedeemed: number;
  tier?: 'starter' | 'pro' | 'champion';
}

export interface Product {
  id: string;
  companyId: string;
  name: string;
  image: string;
  priceKWD: number;
  gender: Gender;
  availableSizes: SizeLabel[];
  isSponsored: boolean;
  stock?: number;
}

export interface Measurements {
  chest: number;
  waist: number;
  hips: number;
  shoulder: number;
  height: number;
  inseam: number;
  sleeve: number;
  neck?: number;
  torso?: number;
  arm_length?: number;
}

export interface GlobalSizes {
  eu: number;
  uk: number;
  us: number;
  it: number;
  fr: number;
  international?: string;
}

export interface ScanRecord {
  id: string;
  userId: string;
  date: string;
  timestamp: number;
  gender: Gender;
  isPregnant: boolean;
  measurements: Measurements;
  sizeLabel: SizeLabel;
  globalSizes: GlobalSizes;
  confidenceScore: number; // 0-100
  method: 'Gemini Vision' | 'Fallback Estimation';
}

export interface LogEntry {
  id: string;
  timestamp: string;
  action: string;
  details: string;
}

export interface ChartData {
  label: string;
  value: number;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  image?: string;
  timestamp: string;
  likes: number;
  comments: number;
}

export interface Coupon {
  id: string;
  code: string;
  discount: string;
  companyName: string;
  description: string;
  expiry: string;
  isRedeemed: boolean;
  status: 'active' | 'redeemed' | 'expired';
}
