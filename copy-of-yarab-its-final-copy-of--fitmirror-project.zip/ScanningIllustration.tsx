import React from 'react';

export const ScanningIllustration = ({ className = "" }: { className?: string }) => (
  <svg viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Background Circle */}
    <circle cx="200" cy="200" r="180" fill="#F3F4F6" className="dark:fill-gray-800" />
    
    {/* Abstract Phone/Device Frame */}
    <rect x="100" y="60" width="200" height="280" rx="20" fill="white" stroke="#E5E7EB" strokeWidth="4" className="dark:fill-gray-900 dark:stroke-gray-700" />
    
    {/* Abstract Modest Person */}
    <circle cx="200" cy="160" r="25" fill="#94A3B8" />
    <path d="M160 340V220C160 203.431 173.431 190 190 190H210C226.569 190 240 203.431 240 220V340" fill="#94A3B8" />
    
    {/* Scanning UI Overlay */}
    <rect x="120" y="80" width="160" height="240" rx="8" stroke="#3C82F6" strokeWidth="2" strokeDasharray="6 6" opacity="0.5" />
    
    {/* Moving Scan Line */}
    <line x1="100" y1="100" x2="300" y2="100" stroke="#3C82F6" strokeWidth="3" opacity="0.8">
      <animate attributeName="y1" from="80" to="320" dur="2.5s" repeatCount="indefinite" />
      <animate attributeName="y2" from="80" to="320" dur="2.5s" repeatCount="indefinite" />
      <animate attributeName="opacity" values="0.4;1;0.4" dur="2.5s" repeatCount="indefinite" />
    </line>
    
    {/* Bottom Indicator */}
    <rect x="180" y="315" width="40" height="4" rx="2" fill="#CBD5E1" />
  </svg>
);