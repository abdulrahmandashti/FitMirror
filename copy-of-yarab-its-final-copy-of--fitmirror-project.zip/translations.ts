
export const translations = {
  en: {
    common: {
      fitMirror: "FitMirror",
      signIn: "Sign In",
      signUp: "Sign Up",
      signOut: "Sign Out",
      scanAgain: "Scan Again",
      saveResults: "Save Results",
      processing: "Analyzing with AI...",
      rights: "© 2025 FitMirror. All rights reserved.",
      builtBy: "Built by: Abdulrahman Dashti, Jassem Alzaid, Yasmeen Qassem, Fatimah Alkandari – Kuwait Maastricht College of Management",
      delete: "Delete",
      edit: "Edit",
      add: "Add",
      cancel: "Cancel",
      save: "Save",
      loading: "Loading...",
      view: "View",
      submit: "Submit",
      messageSent: "Message sent successfully!",
      noAccount: "Don't have an account?",
      haveAccount: "Already have an account?",
      fullName: "Full Name",
      username: "Username",
      email: "Email Address",
      password: "Password",
      confirmPassword: "Confirm Password",
      createAccount: "Create Account",
      role: "Role",
      status: "Status",
      company: "Company",
      actions: "Actions",
      active: "Active",
      disabled: "Disabled",
      addUser: "Add User",
      editUser: "Edit User",
      deleteProductConfirm: "Are you sure you want to delete this product?",
      productImage: "Product Image",
      selectImage: "Select Image",
      continueGuest: "Continue as Guest",
      googleLogin: "Continue with Google",
      appleLogin: "Continue with Apple",
      or: "OR",
      gender: "Gender",
      male: "Male",
      female: "Female",
      height: "Height (cm)",
      weight: "Weight (kg)",
      stock: "Stock",
    },
    nav: {
      home: "Home",
      scan: "Start Scan",
      stores: "Solutions for Stores",
      pricing: "Pricing",
      community: "Community",
      about: "About Us",
      contact: "Contact Us",
      dashboard: "Dashboard",
      login: "Login",
      privacy: "Privacy Policy",
      terms: "Terms of Service",
    },
    hero: {
      title: "Find Your Perfect Size",
      subtitle: "AI-powered body measurement for precise fashion fitting.",
      ctaScan: "Start Your Scan",
      ctaStores: "Solutions for Stores",
      rogers1: "See How It Works",
      rogers2: "Why It Matters",
      rogers3: "Try It Now",
      leaderboardTitle: "Top FitMirror Partner Brands",
      rankingNote: "Ranking based on FitMirror size-matching and engagement data.",
      topPartner: "Top Partner",
      strongPerformer: "Strong Performer",
      activePartner: "Active Partner",
    },
    scan: {
      title: "FitMirror AI Scan",
      instruction: "Automated 4-Step Body Analysis using Gemini Vision.",
      preScanTitle: "Tell us about yourself",
      startFitMirrorScan: "Start FitMirror Scan",
      scanning: "Scanning in progress...",
      scanningFront: "Step 1: Front View (Checking pose...)",
      scanningLeft: "Step 2: Left Side (Checking pose...)",
      scanningBack: "Step 3: Back View (Checking pose...)",
      scanningRight: "Step 4: Right Side (Checking pose...)",
      analyzing: "Analyzing biometrics with AI...",
      confidence: "AI Confidence",
      measurements: "Your Measurements",
      recommended: "Recommended Size",
      sizes: "International Sizes",
      chest: "Chest",
      waist: "Waist",
      hips: "Hips",
      shoulder: "Shoulder",
      inseam: "Inseam",
      sleeve: "Sleeve",
      neck: "Neck",
      torso: "Torso Length",
      height: "Height",
      pregnantMode: "Pregnancy Mode (Predicts +1 Month)",
      disclaimer: "Estimations are based on computer vision analysis.",
      cancelScan: "Cancel Scan",
      capture: "Capture Photo",
      voice: {
        front: "Stand straight facing the camera. I need your full body in the frame.",
        left: "Turn to your left side. Keep your body fully visible.",
        back: "Turn around so your back faces the camera.",
        right: "Turn to your right side. Hold still in the frame.",
        perfect: "Perfect. Hold still… capturing now.",
        processing: "Hold still. We are calculating your measurements.",
        complete: "Scan complete. Here are your recommended sizes.",
        error: "Something went wrong. Please try scanning again.",
        validationFail: "I can't see you clearly. Please step back and stand straight."
      },
      status: {
        checking: "Checking pose with AI...",
        perfect: "Perfect! Capturing...",
        moveBack: "Please move back to show full body.",
        straighten: "Please stand straight.",
        lighting: "Lighting is too poor."
      }
    },
    dashboard: {
      adminTitle: "System Administration",
      partnerTitle: "Partner Portal",
      customerTitle: "My Fit Profile",
      totalScans: "Total Scans",
      totalRevenue: "Total Revenue",
      returnSavings: "Return Savings",
      activeUsers: "Active Users",
      matches: "Product Matches",
      addProduct: "Add New Product",
      manageUsers: "Manage Users",
      logs: "System Logs",
      leaderboard: "Partner Leaderboard",
      rank: "Rank",
      score: "Performance Score",
      coupons: "Coupons",
      couponsIssued: "Coupons Issued",
      couponsRedeemed: "Coupons Redeemed",
    },
    profile: {
      welcome: "Welcome back",
      history: "Scan History",
      myCoupons: "My Coupons",
      code: "Code",
      validUntil: "Valid Until",
      redeemed: "Redeemed",
      active: "Active",
      expired: "Expired",
    },
    stores: {
      title: "FitMirror for Fashion E-Commerce & Retail",
      subtitle: "Reduce size-related returns by up to 70% and increase customer confidence with our AI-powered sizing solution.",
      benefits: "Why Partner with FitMirror?",
      benefit1: "Reduce Returns by 70%",
      benefit2: "Increase Conversion Rates",
      benefit3: "Seamless API Integration",
      apiDocs: "API Documentation",
      apiIntro: "For technical teams, FitMirror exposes a simple REST API to integrate size recommendations directly into your PDPs.",
      integrationGuide: "Integration Guide",
      contactSales: "Talk to Sales",
      viewPricing: "View Pricing",
      metricReturns: "70% Reduction in Returns",
      metricSat: "5.0/5.0 Satisfaction Score",
      metricConv: "+18% Conversion Uplift",
      metricScans: "Thousands of Monthly Scans",
      howItWorks: "How It Works for Stores",
      step1: "Connect Store",
      step1Desc: "Integrate via API or Plugin",
      step2: "Customer Scan",
      step2Desc: "Shoppers scan once",
      step3: "AI Recommend",
      step3Desc: "Instant size matching",
      step4: "Track Analytics",
      step4Desc: "Monitor ROI & Insights",
      plansTitle: "Flexible Plans for Every Stage",
      viewFullPricing: "View Full Pricing"
    },
    pricing: {
      title: "Simple, Transparent Pricing",
      subtitle: "Choose the plan that fits your business scale.",
      note: "FitMirror is free for end customers. Pricing applies only to partner brands and stores.",
      starter: {
        title: "Starter",
        price: "120 KWD",
        period: "/ month",
        desc: "For new and growing brands.",
        features: [
          "Brand placement in recommendations",
          "Product visibility to customers",
          "Partner Dashboard Access (basic)",
          "Basic Analytics: Top viewed products, Basic match rate, Click-through rate",
          "Email Support"
        ],
        cta: "Start Building Your Presence"
      },
      pro: {
        title: "Pro",
        price: "250 KWD",
        period: "/ month",
        desc: "Growth package — unlock advanced visibility & performance tools.",
        features: [
          "Boosted Placement (higher ranking)",
          "Preferred Recommendations in Fit Results & Feeds",
          "Professional Dashboard Tools: Add/Edit products, High-res images, Pricing",
          "Pro Analytics: Conversion Intent, Top products, Customer insights",
          "Priority Support (Email + Call)",
          "Partner Performance Badge & Leaderboard Visibility"
        ],
        cta: "Upgrade Your Brand Performance"
      },
      champion: {
        title: "Champion",
        price: "350 KWD",
        period: "/ month",
        desc: "Top-tier exposure. Full control. Maximum visibility.",
        features: [
          "Premium Placement (Highest ranking)",
          "Exclusive Featured Partner Spot",
          "Maximum Exposure: Top 3 in recommendations, Scan Results visibility",
          "Elite Dashboard: Campaign Builder, Seasonal Collections, Video upload",
          "Full Analytics Suite: HeatMaps, Customer journey, Predictive analytics",
          "24/7 Support + Dedicated Account Manager",
          "Top Partner Badge & Early Access"
        ],
        cta: "Dominate FitMirror — Go Champion"
      }
    },
    community: {
      title: "Community Timeline",
      subtitle: "See how others are finding their perfect fit.",
      share: "Share your experience...",
      topMonth: "Top of the Month",
      likes: "Likes",
      comments: "Comments",
      postButton: "Post Update",
      loginToPost: "Log in to share your story",
      couponEarned: "You earned a coupon!",
      couponBannerTitle: "Engage & Earn Rewards",
      couponBannerText: "Share your outfit experience and engage with the community. Active posts may earn you exclusive coupons from our partner brands!",
    },
    contact: {
      title: "Contact Us",
      subtitle: "Have questions? We'd love to hear from you.",
      name: "Your Name",
      email: "Email Address",
      message: "Message",
    },
    about: {
      title: "About FitMirror",
      story: "Born from the need to solve the e-commerce sizing dilemma.",
      mission: "To empower shoppers and retailers with precise AI technology.",
      privacy: "Your Privacy Matters",
      privacyText: "Images are processed in real-time and never permanently stored.",
    },
    legal: {
      privacyPolicy: "Privacy Policy",
      terms: "Terms of Service",
      updated: "LAST UPDATED: DECEMBER 2025",
      privacyContent: `
        <h3>1. Camera Usage</h3>
        <p>FitMirror uses your device's camera solely to capture a temporary image for the purpose of body measurement. This process happens in real-time.</p>
        
        <h3>2. Image Processing</h3>
        <p>Images captured are transmitted securely to our AI engine (Gemini) for analysis. Once the measurements are extracted, the raw image data is discarded. We do not permanently store your photos on our servers.</p>
        
        <h3>3. Measurement Data</h3>
        <p>We store your numerical measurements (chest, waist, hips, etc.) and size history to provide you with a persistent profile. You can delete this history at any time.</p>
        
        <h3>4. Data Sharing</h3>
        <p>We do not sell your personal data. Aggregated, anonymized measurement data may be used to help partner stores improve their sizing charts, but this cannot be traced back to you.</p>
        
        <h3>5. AI Technology</h3>
        <p>Our service relies on advanced AI estimation. While highly accurate, these are machine-generated estimates used for clothing sizing recommendations.</p>
      `,
      termsContent: `
        <h3>1. Service Description</h3>
        <p>FitMirror is an AI-powered tool designed to assist users in finding their clothing size for online shopping. It provides size recommendations based on visual analysis.</p>
        
        <h3>2. Acceptable Use</h3>
        <p>You agree to use FitMirror only for its intended purpose. Any attempt to manipulate the system, scrape data, or misuse the API is strictly prohibited.</p>
        
        <h3>3. Limitation of Liability</h3>
        <p>Size recommendations are estimates. FitMirror is not responsible for items that do not fit perfectly. The final purchasing decision rests with the user.</p>
        
        <h3>4. Intellectual Property</h3>
        <p>All logos, branding, and code associated with FitMirror (including the JAS KUWAIT partnership assets) are the property of their respective owners.</p>
        
        <h3>5. Termination</h3>
        <p>We reserve the right to suspend accounts that violate these terms or abuse the platform.</p>
      `
    }
  },
  ar: {
    common: {
      fitMirror: "فت ميرور",
      signIn: "تسجيل الدخول",
      signUp: "إنشاء حساب",
      signOut: "تسجيل الخروج",
      scanAgain: "مسح جديد",
      saveResults: "حفظ النتائج",
      processing: "جاري التحليل بالذكاء الاصطناعي...",
      rights: "© 2025 فت ميرور. جميع الحقوق محفوظة.",
      builtBy: "تم التطوير بواسطة: عبد الرحمن دشتي، جاسم الزيد، ياسمين قاسم، فاطمة الكندري – كلية الكويت ماستريخت لإدارة الأعمال",
      delete: "حذف",
      edit: "تعديل",
      add: "إضافة",
      cancel: "إلغاء",
      save: "حفظ",
      loading: "جاري التحميل...",
      view: "عرض",
      submit: "إرسال",
      messageSent: "تم إرسال الرسالة بنجاح!",
      noAccount: "ليس لديك حساب؟",
      haveAccount: "لديك حساب بالفعل؟",
      fullName: "الاسم الكامل",
      username: "اسم المستخدم",
      email: "البريد الإلكتروني",
      password: "كلمة المرور",
      confirmPassword: "تأكيد كلمة المرور",
      createAccount: "إنشاء الحساب",
      role: "الدور",
      status: "الحالة",
      company: "الشركة",
      actions: "إجراءات",
      active: "نشط",
      disabled: "معطل",
      addUser: "إضافة مستخدم",
      editUser: "تعديل المستخدم",
      deleteProductConfirm: "هل أنت متأكد أنك تريد حذف هذا المنتج؟",
      productImage: "صورة المنتج",
      selectImage: "اختر صورة",
      continueGuest: "الاستمرار كضيف",
      googleLogin: "المتابعة مع Google",
      appleLogin: "المتابعة مع Apple",
      or: "أو",
      gender: "الجنس",
      male: "ذكر",
      female: "أنثى",
      height: "الطول (سم)",
      weight: "الوزن (كجم)",
      stock: "المخزون",
    },
    nav: {
      home: "الرئيسية",
      scan: "ابدأ المسح",
      stores: "حلول المتاجر",
      pricing: "الأسعار",
      community: "المجتمع",
      about: "من نحن",
      contact: "اتصل بنا",
      dashboard: "لوحة التحكم",
      login: "دخول",
      privacy: "سياسة الخصوصية",
      terms: "شروط الخدمة",
    },
    hero: {
      title: "اكتشف مقاسك المثالي",
      subtitle: "قياسات دقيقة للجسم باستخدام الذكاء الاصطناعي.",
      ctaScan: "ابدأ المسح الآن",
      ctaStores: "حلول الشركات",
      rogers1: "كيف يعمل",
      rogers2: "لماذا فت ميرور",
      rogers3: "جربه الآن",
      leaderboardTitle: "أفضل العلامات التجارية الشريكة",
      rankingNote: "يعتمد التصنيف على دقة المقاسات وتفاعل العملاء.",
      topPartner: "شريك متميز",
      strongPerformer: "أداء قوي",
      activePartner: "شريك نشط",
    },
    scan: {
      title: "تحليل الجسم",
      instruction: "جرب تقنية المسح بالذكاء الاصطناعي. لا يتم تخزين الصور.",
      preScanTitle: "أخبرنا عن نفسك",
      startFitMirrorScan: "ابدأ مسح فت ميرور",
      scanning: "جاري المسح...",
      scanningFront: "الخطوة 1: الأمام (جاري التحقق...)",
      scanningLeft: "الخطوة 2: الجانب الأيسر (جاري التحقق...)",
      scanningBack: "الخطوة 3: الخلف (جاري التحقق...)",
      scanningRight: "الخطوة 4: الجانب الأيمن (جاري التحقق...)",
      analyzing: "جيمناي فيجن يقوم بتحليل بياناتك...",
      confidence: "دقة الذكاء الاصطناعي",
      measurements: "قياساتك",
      recommended: "المقاس المقترح",
      sizes: "المقاسات العالمية",
      chest: "الصدر",
      waist: "الخصر",
      hips: "الورخ",
      shoulder: "الأكتاف",
      inseam: "طول الساق الداخلي",
      sleeve: "طول الكم",
      neck: "الرقبة",
      torso: "طول الجذع",
      height: "الطول",
      pregnantMode: "وضع الحمل (توقع الشهر القادم)",
      disclaimer: "التقديرات مبنية على تحليل الرؤية الحاسوبية.",
      cancelScan: "إلغاء المسح",
      capture: "التقاط صورة",
      voice: {
        front: "قف بشكل مستقيم أمام الكاميرا. أحتاج أن أرى جسمك بالكامل.",
        left: "در إلى جانبك الأيسر. أبقِ جسمك ظاهراً بالكامل.",
        back: "در ليصبح ظهرك للكاميرا.",
        right: "در إلى جانبك الأيمن. اثبت في مكانك.",
        perfect: "ممتاز. اثبت مكانك... جاري الالتقاط.",
        processing: "اثبت مكانك. نقوم بحساب قياساتك.",
        complete: "تم المسح. إليك المقاسات المقترحة.",
        error: "حدث خطأ ما. يرجى محاولة المسح مرة أخرى.",
        validationFail: "لا أستطيع رؤيتك بوضوح. تراجع للوراء وقف بشكل مستقيم."
      },
      status: {
        checking: "الذكاء الاصطناعي يتحقق من الوضعية...",
        perfect: "ممتاز! جاري الالتقاط...",
        moveBack: "الرجاء الرجوع للخلف لإظهار كامل الجسم.",
        straighten: "الرجاء الوقوف بشكل مستقيم.",
        lighting: "الإضاءة ضعيفة جداً."
      }
    },
    dashboard: {
      adminTitle: "إدارة النظام",
      partnerTitle: "بوابة الشركاء",
      customerTitle: "ملفي الشخصي",
      totalScans: "إجمالي المسح",
      totalRevenue: "إجمالي الإيرادات",
      returnSavings: "وفورات المرتجعات",
      activeUsers: "المستخدمين النشطين",
      matches: "تطابق المنتجات",
      addProduct: "إضافة منتج",
      manageUsers: "إدارة المستخدمين",
      logs: "سجلات النظام",
      leaderboard: "لائحة الشركاء المتصدرين",
      rank: "الترتيب",
      score: "نقاط الأداء",
      coupons: "القسائم",
      couponsIssued: "القسائم المصدرة",
      couponsRedeemed: "القسائم المستخدمة",
    },
    profile: {
      welcome: "مرحباً بك",
      history: "سجل القياسات",
      myCoupons: "قسائمي",
      code: "الكود",
      validUntil: "صالح حتى",
      redeemed: "مستخدم",
      active: "نشط",
      expired: "منتهي",
    },
    stores: {
      title: "فت ميرور للتجارة الإلكترونية",
      subtitle: "قلل المرتجعات بنسبة تصل إلى 70% وزد ثقة العملاء مع حلول القياس بالذكاء الاصطناعي.",
      benefits: "لماذا فت ميرور؟",
      benefit1: "تقليل المرتجعات بنسبة 70%",
      benefit2: "زيادة معدلات التحويل",
      benefit3: "ربط برمجي سهل (API)",
      apiDocs: "وثائق الربط البرمجي",
      apiIntro: "للفرق التقنية، يوفر فت ميرور واجهة برمجة تطبيقات REST بسيطة لدمج توصيات المقاس مباشرة في صفحات المنتجات.",
      integrationGuide: "دليل الدمج",
      contactSales: "تحدث مع المبيعات",
      viewPricing: "عرض الأسعار",
      metricReturns: "70% تخفيض في المرتجعات",
      metricSat: "5.0/5.0 تقييم الرضا",
      metricConv: "+18% زيادة في التحويل",
      metricScans: "آلاف العمليات شهرياً",
      howItWorks: "كيف يعمل للمتاجر",
      step1: "ربط المتجر",
      step1Desc: "عبر API أو إضافة",
      step2: "مسح العميل",
      step2Desc: "مسح واحد فقط",
      step3: "توصية ذكية",
      step3Desc: "مطابقة فورية للمقاس",
      step4: "تحليلات الأداء",
      step4Desc: "متابعة العائد والاستقرار",
      plansTitle: "خطط مرنة لكل مرحلة",
      viewFullPricing: "عرض الأسعار الكاملة"
    },
    pricing: {
      title: "أسعار بسيطة وشفافة",
      subtitle: "اختر الخطة التي تناسب حجم عملك.",
      note: "فت ميرور مجاني للعملاء النهائيين. الأسعار تنطبق فقط على العلامات التجارية والمتاجر الشريكة.",
      starter: {
        title: "ستارتر",
        price: "120 د.ك",
        period: "/ شهرياً",
        desc: "للعلامات التجارية الجديدة والنامية.",
        features: [
          "عرض العلامة التجارية في التوصيات",
          "ظهور المنتجات للعملاء",
          "وصول أساسي للوحة تحكم الشركاء",
          "تحليلات أساسية: المشاهدات، معدل التطابق",
          "دعم عبر البريد الإلكتروني"
        ],
        cta: "ابدأ بناء حضورك"
      },
      pro: {
        title: "برو",
        price: "250 د.ك",
        period: "/ شهرياً",
        desc: "باقة النمو - أدوات متقدمة للظهور والأداء.",
        features: [
          "ظهور معزز (ترتيب أعلى)",
          "توصيات مفضلة في النتائج والخلاصة",
          "أدوات احترافية: إدارة المنتجات، صور عالية الدقة",
          "تحليلات برو: نية الشراء، رؤى العملاء",
          "دعم ذو أولوية (بريد + اتصال)",
          "شارة الأداء القوي"
        ],
        cta: "طوّر أداء علامتك"
      },
      champion: {
        title: "شامبيون",
        price: "350 د.ك",
        period: "/ شهرياً",
        desc: "أعلى مستوى من الظهور والتحكم.",
        features: [
          "ظهور مميز (أعلى ترتيب)",
          "مكان حصري للشركاء المميزين",
          "أقصى تعرض: توب 3 دائماً",
          "أدوات النخبة: حملات، مجموعات موسمية، فيديو",
          "جناح تحليلات كامل: خرائط حرارية، تنبؤات",
          "دعم 24/7 + مدير حساب مخصص",
          "شارة الشريك الأفضل"
        ],
        cta: "سيطر على السوق - كن شامبيون"
      }
    },
    community: {
      title: "يوميات المجتمع",
      subtitle: "شاهد كيف يجد الآخرون مقاسهم المثالي.",
      share: "شارك تجربتك...",
      topMonth: "الأفضل هذا الشهر",
      likes: "إعجابات",
      comments: "تعليقات",
      postButton: "نشر التحديث",
      loginToPost: "سجل الدخول لتشارك قصتك",
      couponEarned: "لقد ربحت قسيمة!",
      couponBannerTitle: "تفاعل واربح المكافآت",
      couponBannerText: "شارك تجربتك وتفاعل مع المجتمع. المشاركات النشطة قد تؤهلك للحصول على قسائم حصرية من شركائنا!",
    },
    contact: {
      title: "اتصل بنا",
      subtitle: "هل لديك أسئلة؟ نود أن نسمع منك.",
      name: "اسمك",
      email: "البريد الإلكتروني",
      message: "الرسالة",
    },
    about: {
      title: "عن فت ميرور",
      story: "انطلقنا لحل مشكلة المقاسات في التجارة الإلكترونية.",
      mission: "تمكين المتسوقين والتجار بتقنيات ذكية دقيقة.",
      privacy: "خصوصيتك تهمنا",
      privacyText: "تتم معالجة الصور لحظياً ولا يتم تخزينها أبداً.",
    },
    legal: {
      privacyPolicy: "سياسة الخصوصية",
      terms: "شروط الخدمة",
      updated: "LAST UPDATED: DECEMBER 2025",
      privacyContent: `
        <h3>1. استخدام الكاميرا</h3>
        <p>يستخدم فت ميرور كاميرا جهازك فقط لالتقاط صورة مؤقتة لغرض قياس الجسم. تحدث هذه العملية في الوقت الفعلي.</p>
        
        <h3>2. معالجة الصور</h3>
        <p>يتم إرسال الصور الملتقطة بشكل آمن إلى محرك الذكاء الاصطناعي (Gemini) للتحليل. بمجرد استخراج القياسات، يتم التخلص من بيانات الصورة الخام. نحن لا نقوم بتخزين صورك بشكل دائم على خوادمنا.</p>
        
        <h3>3. بيانات القياس</h3>
        <p>نقوم بتخزين قياساتك الرقمية (الصدر، الخصر، الوركين، إلخ) وسجل المقاسات لتوفير ملف تعريف دائم لك. يمكنك حذف هذا السجل في أي وقت.</p>
        
        <h3>4. مشاركة البيانات</h3>
        <p>نحن لا نبيع بياناتك الشخصية. قد يتم استخدام بيانات القياس المجمعة والمجهولة لمساعدة المتاجر الشريكة في تحسين جداول مقاساتها، ولكن لا يمكن تتبع هذه البيانات إليك.</p>
        
        <h3>5. تقنية الذكاء الاصطناعي</h3>
        <p>يعتمد خدمتنا على تقديرات الذكاء الاصطناعي المتقدمة. على الرغم من دقتها العالية، فإن هذه تقديرات تم إنشاؤها آلياً وتستخدم لتوصيات مقاسات الملابس.</p>
      `,
      termsContent: `
        <h3>1. وصف الخدمة</h3>
        <p>فت ميرور هي أداة مدعومة بالذكاء الاصطناعي مصممة لمساعدة المستخدمين في العثور على مقاس ملابسهم للتسوق عبر الإنترنت.</p>
        
        <h3>2. الاستخدام المقبول</h3>
        <p>توافق على استخدام فت ميرور فقط للغرض المقصود منه. يمنع منعاً باتاً أي محاولة للتلاعب بالنظام أو استخراج البيانات أو إساءة استخدام واجهة برمجة التطبيقات.</p>
        
        <h3>3. حدود المسؤولية</h3>
        <p>توصيات المقاس هي تقديرات. فت ميرور ليست مسؤولة عن العناصر التي لا تناسب تماماً. قرار الشراء النهائي يقع على عاتق المستخدم.</p>
        
        <h3>4. الملكية الفكرية</h3>
        <p>جميع الشعارات والعلامات التجارية والرموز المرتبطة بـ فت ميرور (بما في ذلك أصول شراكة JAS KUWAIT) هي ملك لأصحابها المعنيين.</p>
        
        <h3>5. الإنهاء</h3>
        <p>نحتفظ بالحق في تعليق الحسابات التي تنتهك هذه الشروط أو تسيء استخدام المنصة.</p>
      `
    }
  }
};
