import React from 'react';

export const FitMirrorLogo = ({ className = "h-8" }: { className?: string }) => (
  <div className={`fitmirror-logo flex items-center gap-2 ${className}`} dir="ltr">
    <svg viewBox="0 0 40 40" className="h-full w-auto" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="4" width="32" height="32" rx="8" className="stroke-primary" strokeWidth="3" />
      <path d="M12 28C12 24 15 22 20 22C25 22 28 24 28 28" className="stroke-primary" strokeWidth="3" strokeLinecap="round" />
      <circle cx="20" cy="15" r="5" className="fill-primary" />
    </svg>
    <span className="font-sans font-bold text-xl tracking-tight text-slate-800 dark:text-white">
      FitMirror
    </span>
  </div>
);